# Français Plus – A1 à B2

Plateforme học tiếng Pháp song ngữ Pháp–Việt. Dự án giữ kiến trúc hiện tại: frontend tĩnh trên GitHub Pages và Cloudflare Worker làm API gateway cho bốn trợ lý AI.

## Module đã triển khai trong bản nâng cấp

1. **Dashboard:** thống kê học tập, tiến độ theo A1–B2, mục tiêu luyện tập trong ngày, gợi ý tiếp tục phiên học gần nhất.
2. **Exercise System:** ngân hàng 2.000 câu hỏi thực hành (500 câu/cấp độ), mã câu hỏi riêng, lọc dạng bài, chọn số lượng câu, xáo trộn đề, chấm điểm, giải thích đáp án và lưu câu sai để ôn lại.
3. **Vocabulary Bank:** 200 mục từ/cụm từ gốc phân theo bốn cấp độ, tìm kiếm Pháp–Việt, lọc cấp độ, câu ví dụ, đọc phát âm bằng SpeechSynthesis và đánh dấu từ đã ôn.
4. **Progress Tracking:** lưu kết quả, Unité hoàn thành, từ đã ôn, lịch sử, câu sai và mục tiêu hằng ngày trong localStorage; hỗ trợ xuất/nhập JSON để sao lưu hoặc chuyển thiết bị.

Nội dung được biên soạn mới theo định hướng CEFR và chủ đề tham chiếu Édito 3e édition; không sao chép nguyên văn giáo trình. Ngân hàng 2.000 câu hiện được tạo từ 50 mục từ/cấp độ và 10 dạng diễn đạt bài tập có ID riêng; nên tiếp tục biên tập/duyệt sư phạm trước khi dùng như đề thi chuẩn hóa.

## Chạy website

- Giải nén ZIP.
- Mở `index.html` để chạy thử các module frontend.
- Đưa toàn bộ file trong thư mục lên repository GitHub Pages (giữ nguyên `index.html`, `app.js`, `modules.js`, `worker.js`, `wrangler.toml`, `README.md`).
- Trong GitHub: Settings → Pages → Deploy from a branch → chọn `main` và thư mục `/ (root)`.

## Lưu tiến độ – giới hạn hiện tại

Tiến độ được tự động lưu trên trình duyệt hiện tại bằng `localStorage`. Người học có thể chọn **Xuất dữ liệu tiến độ** để tải JSON và **Nhập dữ liệu** trên thiết bị khác. Cách này hoạt động không cần backend nhưng chưa tự đồng bộ nhiều thiết bị hoặc nhiều tài khoản. Muốn đồng bộ đám mây cần cấu hình thêm dịch vụ tài khoản/cơ sở dữ liệu (ví dụ Supabase), tạo bảng và chính sách RLS; không được coi localStorage là lưu trữ đám mây.

## Kết nối bốn AI Bot

GitHub Pages chỉ host frontend tĩnh. Không đặt API key trong `app.js`, HTML hoặc repository công khai. Website gọi Cloudflare Worker; Worker giữ khóa bí mật và gọi API mô hình AI.

1. Trong `wrangler.toml`, đặt `ALLOWED_ORIGIN` thành origin GitHub Pages, ví dụ `https://TEN-GITHUB.github.io` (không thêm đường dẫn repo).
2. Đặt secret: `npx wrangler secret put OPENAI_API_KEY`.
3. Đặt `OPENAI_MODEL` thành model API thực sự khả dụng cho tài khoản API của bạn.
4. Triển khai: `npx wrangler deploy`.
5. Sao chép URL Worker và thay `https://YOUR-WORKER.workers.dev/api/chat` trong `app.js` bằng URL thật.
6. Kiểm tra endpoint `/api/health`, sau đó thử gửi tin nhắn từ trang web.

## Cấu trúc

- `index.html`: giao diện responsive.
- `app.js`: khóa học, bài học, AI chat và các chức năng nền hiện có.
- `modules.js`: Dashboard, ngân hàng bài tập A1–B2, từ vựng và theo dõi tiến độ.
- `worker.js`: API gateway phía máy chủ.
- `wrangler.toml`: cấu hình Cloudflare Worker.

## Bảo mật và chi phí

- API key chỉ nằm trong secret của Worker.
- CORS không thay thế xác thực; cần bổ sung rate limiting/chống lạm dụng trước khi mở công khai.
- API AI có thể phát sinh phí riêng. Kiểm tra quyền truy cập model, ngân sách và giới hạn chi tiêu trước khi bật.
- Không nhập mật khẩu hoặc thông tin cá nhân nhạy cảm vào chatbot.
